-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2020 at 05:06 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `nursery`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(10) NOT NULL,
  `admin_name` varchar(25) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `assign_order`
--

CREATE TABLE IF NOT EXISTS `assign_order` (
  `id` int(11) NOT NULL,
  `od_id` int(11) NOT NULL,
  `worker_id` int(11) NOT NULL,
  `assign_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assign_order`
--

INSERT INTO `assign_order` (`id`, `od_id`, `worker_id`, `assign_date`, `status`) VALUES
(2, 2, 1, '2020-02-22 07:00:35', 0),
(3, 1, 1, '2020-09-08 01:44:28', 0);

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE IF NOT EXISTS `bookings` (
  `id` int(11) NOT NULL,
  `expert_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `booking_date` date NOT NULL,
  `booking_time` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `expert_id`, `customer_id`, `booking_date`, `booking_time`, `status`) VALUES
(2, 2, 1, '2020-03-04', '8:00-10:00', 2),
(3, 1, 1, '2020-03-04', '8:00-10:00', 1),
(4, 1, 1, '2020-03-05', '4:00-6:00', 2),
(5, 1, 1, '2020-03-14', '2:00-4:00', 0),
(6, 2, 1, '2020-03-05', '10:00-1:00', 1),
(7, 2, 1, '2020-03-31', '10:00-1:00', 3),
(8, 2, 1, '2020-04-06', '8:00-10:00', 1),
(9, 1, 1, '2020-03-27', '2:00-4:00', 3),
(10, 1, 1, '2020-09-08', '10:00-1:00', 1),
(11, 1, 1, '2020-09-11', '10:00-1:00', 2),
(12, 1, 1, '2020-09-08', '8:00-10:00', 0),
(13, 1, 1, '2020-09-18', '2:00-4:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `cart_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `invoice` text NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` text NOT NULL,
  `total` text NOT NULL,
  `order_date` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `order_id`, `invoice`, `product_id`, `customer_id`, `qty`, `price`, `total`, `order_date`, `status`, `created`) VALUES
(8, 2, '95184327', 1, 1, 1, '1500', '1500', '2020-03-02', 1, '2020-03-02 00:53:42'),
(10, 3, '22817993', 1, 1, 2, '1500', '3000', '2020-03-03', 1, '2020-03-03 06:02:15'),
(12, 5, '21655273', 1, 1, 5, '1500', '7500', '2020-03-06', 3, '2020-03-06 04:48:23'),
(15, 8, '86267090', 6, 1, 3, '1000', '3000', '2020-03-12', 1, '2020-03-12 04:08:45'),
(19, 11, '75683594', 4, 1, 1, '250', '250', '2020-03-12', 1, '2020-03-12 06:59:39'),
(23, 12, '72738648', 10, 1, 1, '220', '220', '2020-03-15', 1, '2020-03-15 05:58:12'),
(24, 0, '', 2, 1, 1, '15000', '15000', '2020-09-08', 0, '2020-09-08 11:19:49');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(10) NOT NULL,
  `name` varchar(70) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `status`, `created_date`) VALUES
(4, 'Plants', 0, '2020-02-10 16:32:22'),
(5, 'Fertilizers', 0, '2020-02-10 16:32:35'),
(9, 'Pots', 0, '2020-03-07 05:44:41'),
(10, 'Gardening Accessories', 0, '2020-03-07 05:45:00');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `id` int(10) NOT NULL,
  `cust_name` varchar(70) NOT NULL,
  `cust_contact` text NOT NULL,
  `cust_addr` varchar(100) NOT NULL,
  `cust_email` varchar(50) NOT NULL,
  `cust_password` varchar(25) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `cust_name`, `cust_contact`, `cust_addr`, `cust_email`, `cust_password`) VALUES
(1, 'pratheeksha', '2147483647', 'Mala house,Karkala,Udupi', 'dfgh@gmail.com', 'dfhk'),
(2, 'Deeksha', '9980456789', 'nakre house,karkala', 'deeksha@gmaill.com', 'deeksha123'),
(3, 'shreya', '9878987871', 'karkala, bannimata road', 'shreya@gmail.com', 'shreya12');

-- --------------------------------------------------------

--
-- Table structure for table `delivery_address`
--

CREATE TABLE IF NOT EXISTS `delivery_address` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `invoice` text NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `delivery_address` text NOT NULL,
  `street` text NOT NULL,
  `pincode` text NOT NULL,
  `phone_number` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `order_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery_address`
--

INSERT INTO `delivery_address` (`id`, `customer_id`, `invoice`, `fullname`, `delivery_address`, `street`, `pincode`, `phone_number`, `email`, `order_id`, `status`, `timestamp`) VALUES
(1, 1, '67050171', 'pratheeksha', 'mangalore near pumpwell', 'mangalore', '575005', '2147483647', 'dfgh@gmail.com', 0, 0, '2020-03-01 19:27:13'),
(2, 1, '95184327', 'pratheeksha', 'mangalore', 'mangalore', '575005', '8574859685', 'dfgh@gmail.com', 0, 0, '2020-03-02 00:54:27'),
(3, 1, '22817993', 'pratheeksha', 'eed', 'edededd', '467234', '2147483647', 'dfgh@gmail.com', 0, 0, '2020-03-03 06:03:00'),
(4, 1, '83554077', 'pratheeksha', 'mangalore near pumpwell 111', '2nd', '123456', '2147483647', 'dfgh@gmail.com', 0, 0, '2020-03-06 04:20:25'),
(5, 1, '21655273', 'pratheeksha', 'Alangar', 'Moodbidri', '574227', '2147483647', 'dfgh@gmail.com', 0, 0, '2020-03-06 06:21:41'),
(6, 1, '33605957', 'pratheeksha', '', '', '', '2147483647', 'dfgh@gmail.com', 0, 0, '2020-03-07 04:57:33'),
(7, 1, '62466431', 'pratheeksha', 'karkala near karkala circle', 'karaka', '987098', '2147483647', 'dfgh@gmail.com', 0, 0, '2020-03-08 08:52:20'),
(8, 1, '86267090', 'pratheeksha', 'siddakatte ', 'siddakatte', '574237', '2147483647', 'dfgh@gmail.com', 0, 0, '2020-03-12 04:12:36'),
(9, 1, '99130250', 'pratheeksha', 'alangar', 'alangar', '555555', '9999999999', 'dfgh@gmail.com', 0, 0, '2020-03-12 06:57:29'),
(10, 1, '53933716', 'pratheeksha', 'siddakatte ', 'siddakatte', '555555', '2147483647', 'dfgh@gmail.com', 0, 0, '2020-03-12 06:58:58'),
(11, 1, '75683594', 'pratheeksha', 'siddakatte ', 'siddakatte', '555555', '2147483647', 'dfgh@gmail.com', 0, 0, '2020-03-12 06:59:51'),
(12, 1, '72738648', 'pratheeksha', 'siddakatte ', 'siddakatte', '111111', '2147483647', 'dfgh@gmail.com', 0, 0, '2020-03-15 05:58:39'),
(13, 1, '53536987', 'pratheeksha', 'mangalore near pumpwell', 'mangalore', '111112', '2147483647', 'dfgh@gmail.com', 0, 0, '2020-03-15 06:00:18'),
(14, 1, '66003418', 'pratheeksha', 'karpe post', 'karpe street', '574237', '2147483647', 'dfgh@gmail.com', 0, 0, '2020-09-07 04:08:56');

-- --------------------------------------------------------

--
-- Table structure for table `experts`
--

CREATE TABLE IF NOT EXISTS `experts` (
  `id` int(10) NOT NULL,
  `e_name` varchar(70) NOT NULL,
  `password` varchar(11) NOT NULL,
  `e_img` text NOT NULL,
  `e_contact` text NOT NULL,
  `e_email` varchar(50) NOT NULL,
  `e_addr` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `experts`
--

INSERT INTO `experts` (`id`, `e_name`, `password`, `e_img`, `e_contact`, `e_email`, `e_addr`, `status`, `created_date`) VALUES
(1, 'Prashanth amin', 'expert1000', 'ram3.jpg', '9845014756', 'prashamin@gmail.com', 'Uliya House, Alangar, Mangalore ', 0, '2020-02-10 18:44:14'),
(2, 'Ramin Khan', 'expert1000', 'ram11.jpg', '9087654389', 'rkhan@gmail.com', 'kadari house, Mala, Udupi', 0, '2020-02-10 18:48:04');

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE IF NOT EXISTS `faq` (
  `fid` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `e_id` int(11) NOT NULL,
  `fquest` text NOT NULL,
  `fans` text NOT NULL,
  `fdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`fid`, `cust_id`, `e_id`, `fquest`, `fans`, `fdate`, `status`) VALUES
(1, 1, 1, 'organic or inorganic? ', 'I recommend organic fertilizers.', '2020-03-08 05:39:43', 1),
(3, 1, 2, 'which soil is suitable for growing mango?', 'Black and red soil.', '2020-03-08 05:44:53', 1),
(5, 1, 2, 'which soil is suitable for growing apples?', '', '2020-03-08 05:46:00', 0),
(6, 1, 2, 'what type fertilizers should be used for mossrose.', '', '2020-09-07 06:19:34', 0),
(7, 1, 1, 'which type of soil you recommend for rose plant', '', '2020-09-08 11:37:53', 0);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int(10) NOT NULL,
  `cust_id` int(10) NOT NULL,
  `p_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `details` varchar(200) NOT NULL,
  `status` int(11) DEFAULT '0',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `cust_id`, `p_id`, `rating`, `nickname`, `details`, `status`, `created_date`) VALUES
(1, 1, 2, 3, 'prathor', 'nice product.\r\nHappy with your service.', 0, '2020-02-25 05:42:15'),
(2, 1, 5, 5, 'prats', 'good quality', 0, '2020-09-07 06:27:01');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE IF NOT EXISTS `notification` (
  `id` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `status` text NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`id`, `cust_id`, `status`, `created_date`) VALUES
(1, 1, 'Your order has been Dispatched', '2020-03-15 06:51:35'),
(2, 1, 'Your order has been Dispatched', '2020-09-05 06:28:39'),
(3, 1, 'Your order has been Cancelled due to some issues.', '2020-09-05 08:00:08');

-- --------------------------------------------------------

--
-- Table structure for table `od`
--

CREATE TABLE IF NOT EXISTS `od` (
  `id` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `odate` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `od`
--

INSERT INTO `od` (`id`, `cust_id`, `item_id`, `qty`, `amount`, `odate`, `status`) VALUES
(1, 1, 2, 2, 15000, '2020-02-22', 2),
(2, 1, 1, 3, 1500, '2020-02-22', 1),
(3, 1, 1, 1, 1500, '2020-02-23', 3),
(4, 1, 2, 12, 1234, '2020-02-12', 4),
(5, 1, 2, 11, 9000, '2020-02-23', 4);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE IF NOT EXISTS `order` (
  `id` int(10) NOT NULL,
  `od_id` int(11) NOT NULL,
  `cust_id` int(10) NOT NULL,
  `total_amt` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE IF NOT EXISTS `order_details` (
  `id` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `ite_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `odate` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `cust_id`, `ite_id`, `qty`, `amount`, `odate`, `status`) VALUES
(0, 1, 1, 1, 1500, '2020-02-22', 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `p_name` varchar(70) NOT NULL,
  `p_img1` text NOT NULL,
  `p_img2` text NOT NULL,
  `p_img3` text NOT NULL,
  `p_price` int(11) NOT NULL,
  `p_desc` text NOT NULL,
  `p_qty` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `cat_id`, `p_name`, `p_img1`, `p_img2`, `p_img3`, `p_price`, `p_desc`, `p_qty`, `status`, `created_date`) VALUES
(1, 4, 'Dummy1', 'cement_pots1.jpg', 'medicinal.jpg', 'inorganic_fertilizer1.jpg', 1500, 'Something fd', 100, 0, '2020-02-10 17:10:22'),
(2, 4, 'Rose', '9.jpg', '10.jpg', '11.jpg', 15000, 'rose rose', 49, 0, '2020-02-22 05:31:12'),
(3, 4, 'Allamanda Blanchetii', 'AllamandaBlanchetii1.jpg', 'Allamandablanchetti2.jpg', 'AllamandaBlanchetii3.jpg', 325, 'Pretty violet-shaded flowers are trumpet-shaped, very showy and appear all year in consistently warm climates. This vine has thin, arching, twining woody branches. The bark is brown, furrowed on mature stems and yellow-green on younger branches. These emit a milky irritating sap when broken. The leaves are elliptical in shape, slightly fuzzy, green to yellow-green and appear opposite to one another on the stems. The fruits are spiny seed capsules.\r\n\r\nEnvironment:\r\n\r\nIn temperate regions, allamanda may be grown outdoors in containers during the summer months and brought into a greenhouse or conservatory to over-winter. They require full sun and fertile, well-drained, acidic soil for best growth. Though somewhat drought tolerant, they look and grow best with evenly moist conditions.\r\n\r\nLandscape Use\r\n\r\nPurple allamanda makes a wonderful, ever-blooming specimen plant. Use it to impart a tropical feeling in frost-free landscapes and container gardens.', 100, 0, '2020-03-07 05:48:00'),
(4, 4, 'Bougainvillea ''Delta Dawn''', 'Bougainvillea ''Delta Dawn''1.jpg', 'Bougainvillea ''Delta Dawn''2.jpg', 'Bougainvillea ''Delta Dawn''1.jpg', 250, 'Very vigorous, evergreen, woody vines.Clusters of golden-yellow blooms among the variegated creamy white along the edges of its leaves and green foliage. As the flower matures, it changes to salmon pink. They will bloom beautifully on branches on 18"-20" long. Keep all long shoots cut back to 18"-20" for best bloom. The vibrant color of this vine comes not from the small white tubular flowers, but from the 3 large paper-like bracts that surround each flower.\r\n\r\nEnvironment:\r\nBougainvillea are easy to grow in Fertile, well drained soil in full light. The plant flower if grown under maximum light and stressed with dryness. Bring the soil to a state of visual dryness between watering. The best flowering occurs when the plants are brought to a slight wilt between waterings. When watering, thoroughly saturate the soil until a little water runs out of the bottom of the pot. Growing in a clay pot will help maintain a healthy root system.\r\n\r\nFertilize with a balanced, soluble fertilizer every two weeks at Â½ tsp of fertilizer per gallon of water. Reduce the frequency during the winter months, especially under cool temperatures.\r\n\r\nLandscape Use:\r\nGood for a Hanging Basket & Container', 200, 0, '2020-03-07 05:53:13'),
(5, 9, 'Bowl of Plenty Ceramic Pot', 'pot3.jpg', 'pott2.jpg', 'pot3.jpg', 400, 'Bowl of Plenty is a beautiful handpainted ceramic pot. The colorful tones of this pot makes for a vibrant addition to your home. Best used for planting succulents in. Perfect for gifting too.\r\n\r\nSpecifications :\r\nMaterial : Ceramic\r\n\r\nColor : Green\r\n\r\nSize : H-6cm D-7.5cm\r\n\r\nPlease note : Plant is only for display purposes. This product only includes a ceramic pot.', 228, 0, '2020-03-07 06:07:00'),
(6, 10, '205mm Super Auto-Rotating Ratchet Pruner', '205mm Super Auto-Rotating.jpg', '205mm Super Auto-Rotating.jpg', '205mm Super Auto-Rotating.jpg', 1000, '4-step Anvil Ratchet Type with Rotating Handle increase cutting power by 50% Parallel handle rotation evenly distributes the cutting force, minimizing hand strain and fatigue. The Bypass action makes it ideal for cutting tough living plants professionally, cutting cleanly without crushing branches or tearing bark.For both Right and Left hand users Auto-Rotating Handle minimizes strain and fatigue especially duirng extended use Ratchet 4 short cuts for easy pruning Blade: High carbon steel blade, non-stick coated Handle: Aluminum handles, PP & soft rubber (TPR) grip Size: 205mm (8") Cutting Capacity: 24mm\r\nSpecifications :\r\nMaterial : Metal\r\n\r\nColor : Yellow\r\n\r\nProduct Size L x w x h in Cms : 40x20x10 ', 50, 0, '2020-03-07 06:16:57'),
(7, 4, 'Dwarf Pomegranate', 'Dwarf_Pomegranate1.jpg', 'Dwarf_Pomegranate1.jpg', 'Dwarf_Pomegranate1.jpg', 350, 'The Dwarf Pomegranate is one of the best compact, ornamental shrubs and popular choice for growing Bonsai. The real treat is in the flowers. They look almost like carnations, usually a dazzling orange-red colour, followed by small 5cm ( 2 in) orange -red fruit. \r\n\r\nIt is a dense, deciduous shrub with leaves that are dark with beautiful hues of bronze in late autumn. Its compact size makes it suitable to containers\r\n\r\nEnvironment\r\nPlace the tree outside; the tree does well in full sun. Keep the plant damp, as drought seriously harms the plant.\r\n\r\nIf you want the tree to grow healthy flowers and fruits, use a fertilizer with high phosphorous and high potassium from spring to late summer. If you opt for fast growth remove flowers and use a normal fertilizer.\r\n\r\nPrune back to one or two sets of leaves. If you want the tree to flower wait with any pruning until after blooming.\r\n\r\nRepot Pomegranate Bonsai every two years in spring.\r\n\r\nLandscape Use\r\nIdeal specimen plant for  Bonsai', 150, 0, '2020-03-07 06:27:30'),
(8, 4, 'Red Guava', 'redguava2.jpg', 'redguava3.jpg', 'Red_Guava1.jpg', 120, 'A small tree, with spreading branches, the guava is easy to recognize because of its smooth, thin, copper-colored bark that flakes off, showing the greenish layer beneath; and also because of the attractive, "bony" aspect of its trunk which may in time attain a diameter of 25 cm.    \r\n\r\nEnvironment\r\nThe guava thrives in both humid and dry climates. In India, it flourishes up to an altitude of 3,280 ft (1,000 m.  Older trees, killed to the ground, have sent up new shoots which fruited 2 years later. The guava requires an annual rainfall between 40 and 80 in (1,000-2,000 mm) is said to bear more heavily in areas with a distinct winter season than in the deep Tropics\r\n\r\nSalient Feature\r\nPlants grown from Tissue culture are very healthy and have disease resistant\r\nFruit harvesting will be after 1 year of planting\r\nYellowish green color fruit with inside red color\r\nFruit Size Medium- 200 gms to 400 gms\r\nLess seeds more pulp.\r\nVery sweet in taste.\r\nNutrition facts\r\nGuavas are rich in dietary fiber and vitamin C, with moderate levels of folic acid. Having a generally broad, low-calorie profile of essential nutrients, a single common guava fruit contains about four times the amount of vitamin C as an orange. However, nutrient content varies across guava cultivars. \r\n\r\nLandscape Use\r\nGood for a Garden, Farm & Bonsai', 220, 0, '2020-03-07 06:29:08'),
(9, 5, 'Nutrient Blend - Symphony', 'Nutrient blend symphony.jpg', 'Nutrient blend symphony.jpg', 'Nutrient blend symphony.jpg', 450, 'CG Hydroponics & Soil Nutrient Blend Symphony Combo Pack consists of 100ml each of CG Greens, CG Blooms, and CG Nutes. CG Greens contains all 6 macro-nutrients required by plants with NPK in the ratio of 14:05:14 thus providing almost thrice the amount of Nitrogen as compared to Phosphate. A Higher proportion of Nitrogen promotes healthy roots and extensive leaf growth. CG Greens should be used from germination till the time flowering starts. CG Blooms contains all 6 macro-nutrients required by plants with NPK in the ratio of 06:10:30 thus providing a much higher proportion of Phosphate as compared to Nitrogen. A Higher percentage of Phosphate ensures that plan spends more of its energy in generating fruits and flowers than producing more leaves. CG Blooms should be used from the time flowering starts till harvest. CG Nutes contains all 7 essential micronutrients which help plants to fight against deficiencies caused by lack of micronutrients that are not readily available in soil or water. It boosts plants immunity and promotes the growth of healthy leaf, flower, and fruits. CG Nutes should be used throughout the plan life-cycle from germination till harvest.\r\n\r\n ', 48, 0, '2020-03-14 05:41:10'),
(10, 5, 'Tulsi Super Power Manure - 1Kg', 'Tulsi Super Power Manure1.jpg', 'Tulsi Super Power Manure2.jpg', 'Tulsi Super Power Manure3.jpg', 220, 'Tulsi granules provides balanced nutrition for optimum growth promotion through availability of required amino acids, enzymes, micro nutrients, optimum metabolite formation.\r\n\r\nIt enhances germination of seeds,extends roots & shoots development,increases tolerance to stress,increases flower & fruit setting, improve size, colour, flavour of the product & increases yeild.\r\n\r\nWorks well in salted water & hard land . \r\n\r\nContents : \r\nIt is manufactured by using bio power water soluble liquid basic elements like Sea weed, Humic acid, Amino acid, Neem oil base and also using herbal insecticides by plants fumigation solitaire. \r\n\r\nApplication :\r\n1st   Application - 10 - 12 days after sowing - 1 kg for 100 sq. ft , \r\n2nd  Application - 30 - 40 days after sowing  - 500 gms per 100 Sq Ft', 0, 0, '2020-03-14 05:48:46'),
(11, 5, 'Castor Cake  -50 Kg', 'Castor-Cake1.jpg', 'Castor Cake-2.jpg', 'Castor Cake-3.jpg', 1400, 'Castor Cake is a natural nitrogen fertilizer .It is a simple manure, which acts progressively that encourages soil microbial activity.\r\n\r\nIt  has insecticidal properties and naturally pest repellent. It is can be used in organic farming &  fits for any type of soil, with its high content of organic matter.\r\n\r\nCastor Cake is also the fertilizer for turf and lawns. This fertilizer promotes root development and winter cold hardiness.\r\n\r\nApplication :\r\nWhen it is used as a basic manure,Castor Cake is taken by spreading on the soil 10 to 15 days before planting.\r\nWhen used as a fertilizer for maintenance, it is spread to the surface, slightly hidden if possible, and lightly watered if necessary.\r\n Benefits of Castor Cake :\r\nControls ph ,\r\nIncrease fertility ,\r\nIncreases humus ,\r\nIncreases residual effect ,\r\nIncrease growth of earthworm ,\r\nIncreases shininess of fruit ,\r\nIncrease Nitrogen supply for Root ,\r\nSoil aeration for better root development ,\r\nInhibit growth of termite & other pest ,\r\nRich source of NPK and other micronutrients ,\r\nOrganic Fertilizer, choice of fertilizer for organic farming .\r\n', 54, 0, '2020-03-14 05:53:29'),
(12, 9, 'Ceramic Pot With Tray - 8cmx 9cm', 'Ceramic Pot With Tray1.jpg', 'Ceramic Pot With Tray2.jpg', 'Ceramic Pot With Tray3.jpg', 190, 'Add a dash of colour to your home decor with this absolutely gorgeous ceramic pot coming with a tray. Coming in a beautiful bold tones, this pot is easy on the eye and makes your plant the focal point! .\r\nSpecifications :\r\nSize(H x W) : 8cmx 9cm ,\r\nMedium : Ceramic', 39, 0, '2020-03-14 05:58:58'),
(13, 10, 'Set of Trowel & Hand Cultivator', 'Set of Trowel & Hand Cultivator1.jpg', 'Set of Trowel & Hand Cultivator2.jpg', 'Set of Trowel & Hand Cultivator3.jpg', 245, 'A trowel is a small hand tool used for digging, applying, smoothing, or moving small amounts of viscous or particulate material .\r\n\r\nSpecifications  :\r\nMaterial : Metal .\r\n\r\nColor : Orange & Black .\r\n\r\nProduct Size L x w x h in Cms : 28x9x3 .', 45, 0, '2020-03-14 06:02:50'),
(14, 4, 'xyz', 'favicon.ico', 'pot.png', 's1.png', 100, 'plants', 8, 0, '2020-09-09 06:50:19');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE IF NOT EXISTS `tbl_order` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `invoice` text NOT NULL,
  `order_date` date NOT NULL,
  `grand_total` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`order_id`, `customer_id`, `invoice`, `order_date`, `grand_total`, `status`, `created`) VALUES
(1, 1, '67050171', '2020-03-01', '75000', 1, '2020-03-01 19:27:13'),
(3, 1, '22817993', '2020-03-03', '3000', 2, '2020-03-03 06:03:01'),
(4, 1, '83554077', '2020-03-06', '3000', 4, '2020-03-06 04:20:25'),
(7, 1, '62466431', '2020-03-08', '120', 3, '2020-03-08 08:52:20'),
(8, 1, '86267090', '2020-03-12', '3800', 0, '2020-03-12 04:12:37'),
(9, 1, '99130250', '2020-03-12', '1250', 2, '2020-03-12 06:57:29');

-- --------------------------------------------------------

--
-- Table structure for table `workers`
--

CREATE TABLE IF NOT EXISTS `workers` (
  `id` int(10) NOT NULL,
  `w_name` varchar(70) NOT NULL,
  `password` varchar(11) NOT NULL,
  `w_img` text NOT NULL,
  `w_contact` text NOT NULL,
  `w_email` varchar(50) NOT NULL,
  `w_addr` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workers`
--

INSERT INTO `workers` (`id`, `w_name`, `password`, `w_img`, `w_contact`, `w_email`, `w_addr`, `status`, `created_date`) VALUES
(1, 'Shrikanth', 'worker1000', 'team1.png', '9876543210', 'sr@gmail.com', 'Maanglore', 1, '2020-02-23 04:54:16'),
(2, 'dummy2', 'worker1000', '38.jpg', '8596859855', 'dummy@gmail.com', 'mangalore', 0, '2020-02-23 05:23:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `assign_order`
--
ALTER TABLE `assign_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delivery_address`
--
ALTER TABLE `delivery_address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `experts`
--
ALTER TABLE `experts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`fid`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `od`
--
ALTER TABLE `od`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `workers`
--
ALTER TABLE `workers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `assign_order`
--
ALTER TABLE `assign_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `delivery_address`
--
ALTER TABLE `delivery_address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `experts`
--
ALTER TABLE `experts`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `fid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `od`
--
ALTER TABLE `od`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `workers`
--
ALTER TABLE `workers`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
